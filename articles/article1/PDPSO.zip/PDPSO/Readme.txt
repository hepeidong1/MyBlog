_________________________________________________________________________
PDPSO: Particle swarm optimization based on priority-driven search and 
dynamic candidate solutions management strategy for solving 
complex higher-dimensional engineering problems

 paper:
 Gang Hu, Peidong He.

 E-mails: hg_xaut@xaut.edu.cn           (Gang Hu)
_________________________________________________________________________

The package contains 6 files

(1) main.mlx (RUN!)
        Main function, used to call all functions
(2) cec17_func.mexw64
        Used to call the cost function
(3) input_data17
        Related data for the cost function
(4) PDPSO.m
        This paper
(5) PSO.m
        Original particle swarm algorithm
(6) CEC2017.m
        Related information (boundary, dimension) for the CEC2017