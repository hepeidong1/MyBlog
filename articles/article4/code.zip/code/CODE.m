clear; close all;

%% 算法参数设置
max_iter = 1000;      % 最大迭代次数
step_size = 50;        % 单步扩展距离
radius = 50;           % 近邻搜索半径
goal_radius = 20;      % 目标点接受半径

%% 运行时选项
show_runtime = 1;      % 显示运行时可视化
profile off;            % 性能分析关闭

%% 地图加载与预处理
img1 = imread("Pictures/map1.jpg"); 
img = imbinarize(im2gray(img1), 0.8);  % 灰度化并二值化
se = strel('disk', 1); 
img = ~imdilate(~img, se);             % 形态学处理
map_size = size(img);                  % 获取地图尺寸

%% 交互式选择起点终点
figure; 
set(gcf, 'Position', [100, 100, 800, 600]);
imshow(img, 'InitialMagnification', 'fit');
hold on;
title('选择起始点(绿)和目标点(红)');

% 选择起点
[start_x, start_y] = ginput(1); 
start = [round(start_x), round(start_y)];
plot(start(1), start(2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
pause(0.1); 

% 选择终点
[goal_x, goal_y] = ginput(1);
goal = [round(goal_x), round(goal_y)];
plot(goal(1), goal(2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
pause(0.1);
plotCircle(goal, goal_radius);  % 绘制目标区域

%% 主算法执行
tic;
path = HPDrrtstar(img, start, goal, max_iter, step_size, goal_radius,show_runtime);
elapsedtime = toc;

%% 结果输出
if ~isempty(path)
   fprintf('RRT* Smart 路径规划成功! 耗时: %0.2f 秒\n', elapsedtime);
else
    disp('未找到可行路径');
end

%%%%%%%%%%%%%%%%%%%%%%%%%% RRT* Smart 核心算法 %%%%%%%%%%%%%%%%%%%%%%%%%%
function tree = HPDrrtstar(img, start, goal, max_iter, step_size,  goal_radius, show_runtime_plot)
    p = haltonset(2,'Skip',1e3,'Leap',1e2);
    p = scramble(p,'RR2');
    pflag = zeros(1,max_iter);
    map_size = size(img);  % 获取地图尺寸

    % 树结构初始化
    tree.nodes = start;    % 节点坐标
    tree.parent = 0;       % 父节点索引
    tree.cost = 0;         % 路径代价
    tree.edge_handle = NaN; % 边图形句柄（根节点无句柄）
    tree.index = 0;
    
    % RRT* Smart 状态变量
    stage = 1;                   % 初始路径标记
    best_goal_path = [];         % 最优路径
    best_cost = inf;             % 最优路径代价
    beacon_plot = [];            % 信标路径绘图句柄
    
    % 启发式参数计算
    free_space = sum(img(:)) / numel(img);  % 自由空间比例
    total_volume = size(img,1) * size(img,2);
    gamma = 2 * sqrt(free_space * total_volume / pi); % 近邻半径参数
    stop = 0;

    %% 主循环
    for iter = 1:max_iter
        if mod(iter,100) == 0
            fprintf('迭代: %d/%d | 路径代价: %.2f\n', iter, max_iter, best_cost);
        end
        
        [rand_point,index] = adaptive_sample(goal,map_size,p,pflag,stop,start);
        [nearest_idx, nearest_node] = find_nearest_node(tree.nodes, rand_point);

        x_point = round(max(1, min(size(img, 2), rand_point(1))));
        y_point = round(max(1, min(size(img, 1), rand_point(2))));
        if ~img(sub2ind(size(img), y_point, x_point)) && index~=0 %障碍物里面
            pflag(index)=1;
            direction = (rand_point - nearest_node) / norm(rand_point - nearest_node);
            new_node = nearest_node + direction * step_size;
            new_node = round(new_node);
        else % 正常可探索区域
            new_node = rand_point;
        end
        stop = stop + 1 + (rand<0.5) + (rand<0.5) + (rand<0.5);
        current_radius = max(get_optimal_radius(length(tree.nodes), gamma), 15);

        % 路径有效性检查
        if is_path_valid(img, nearest_node, new_node)
            [near_indices, near_nodes] = find_near_nodes(tree.nodes, new_node, current_radius);
            
            if index~=0
                pflag(index)=1;
            end
            stop = 0;
            
            % 1. 选择最优父节点
            min_cost = tree.cost(nearest_idx) + node_distance(nearest_node, new_node);
            
            for i = 1:length(near_indices)
                near_idx = near_indices(i);
                near_node = near_nodes(i, :);
                
                if is_path_valid(img, near_node, new_node)
                    potential_cost = tree.cost(near_idx) + node_distance(near_node, new_node);
                    if potential_cost < min_cost
                        min_cost = potential_cost;
                    end
                end
            end
            
            %  ======= 离散点扩展策略 =======
            distance = node_distance(new_node, nearest_node);
            N_node = ceil(distance/step_size);
            nodes = nearest_node + ([1:1:N_node]'/N_node)*(new_node-nearest_node);

            for node_index = 1:N_node
                new_node = nodes(node_index,:);
                [nearest_idx, nearest_node] = find_nearest_node(tree.nodes, new_node);
                min_cost_idx = nearest_idx;
                min_cost = tree.cost(nearest_idx) + node_distance(nearest_node, new_node);
                [near_indices, near_nodes] = find_near_nodes(tree.nodes, new_node, current_radius);

                % 2. 添加新节点
                tree.nodes(end+1, :) = new_node;
                tree.parent(end+1) = min_cost_idx;
                tree.cost(end+1) = min_cost;
                if node_index==N_node
                    tree.index(end+1) = index;
                else
                    tree.index(end+1) = 0;
                end
                
                % 3. 可视化新边并记录句柄
                if show_runtime_plot
                    color = '#1d953f'; % 橘黄色
                    h = plot([tree.nodes(min_cost_idx,1), new_node(1)],...
                             [tree.nodes(min_cost_idx,2), new_node(2)],...
                             'Color', color, 'LineWidth', 0.5);
                    tree.edge_handle(end+1) = h; % 存储图形句柄
                    drawnow limitrate;
                else
                    tree.edge_handle(end+1) = NaN; % 不显示时填充NaN
                end

                % 4. 重布线优化
                for i = 1:length(near_indices)
                    near_idx = near_indices(i);
                    near_node = near_nodes(i, :);
                    potential_new_cost = min_cost + node_distance(new_node, near_node);

                    if potential_new_cost < tree.cost(near_idx) && is_path_valid(img, new_node, near_node)
                        % 更新父节点和代价
                        tree.parent(near_idx) = length(tree.nodes);
                        tree.cost(near_idx) = potential_new_cost;

                        % ==== 关键修改: 删除旧边 ====
                        if show_runtime_plot
                            delete(tree.edge_handle(near_idx)); % 删除旧边图形
                            
                            % 绘制新边并更新句柄
                            h_new = plot([new_node(1), near_node(1)],...
                                         [new_node(2), near_node(2)],...
                                         'Color', '#1d953f', 'LineWidth', 0.5);
                            tree.edge_handle(near_idx) = h_new; % 更新句柄
                            drawnow limitrate;
                        end

                        % 更新子节点代价
                        update_child_costs(tree, near_idx);
                    end
                end
            end
            
            % 5. 目标检查与信标更新 (RRT* Smart 核心)
            distance_to_goal = norm(new_node - goal);
            if distance_to_goal <= goal_radius
                if stage==1
                    goal_ind = length(tree.nodes);
                end
                [current_path, current_cost] = reconstruct_path(tree, goal_ind);
                
                % 添加最后一段到目标的距离
                current_cost = current_cost + distance_to_goal;
                
                if isempty(best_goal_path) || current_cost < best_cost
                    best_goal_path = current_path;
                    best_cost = current_cost;
                    
                    % 路径优化生成信标点 (RRT* Smart 核心)
                    beacons = path_optimization(best_goal_path, img);
                    
                    % ===== 首次找到路径的特殊处理 =====
                    if stage == 1
                        stage = 2;
                        fprintf('---- 找到初始路径! 进入优化阶段 ----\n');
                    end
                    
                    % 更新信标可视化
                    if show_runtime_plot
                        if ~isempty(beacon_plot)
                            delete(beacon_plot);
                        end
                        beacon_plot = plot(beacons(:,1), beacons(:,2), 'r-', 'LineWidth', 3);
                        title(sprintf('RRT* Smart | 迭代: %d | 代价: %.2f', iter, best_cost));
                        drawnow;
                    end
                    
                    fprintf('路径优化: 新代价 %.2f\n', best_cost);
                end
            end
        end
    end
    
    %% 最终路径处理
    if ~isempty(best_goal_path)
        % 最终路径优化
        final_beacons = path_optimization(best_goal_path, img);
        
        % 可视化
        if show_runtime_plot
            delete(beacon_plot);
            % 绘制最终信标路径 (紫色)
            plot(final_beacons(:,1), final_beacons(:,2), 'm-', 'LineWidth', 3);
            drawnow;
        end
        
        % 输出信标路径作为最终结果
        path = final_beacons;
        fprintf('RRT* Smart 最优路径代价: %.2f\n', best_cost);
        title(sprintf('RRT* Smart 完成! 代价: %.2f', best_cost));
    else
        path = [];
        disp('达到最大迭代次数未找到路径');
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%% RRT* Smart 核心函数 %%%%%%%%%%%%%%%%%%%%%%%%%%

%% 信标采样函数 (核心创新)
function rand_point = sample_near_beacons(beacons, radius, img)
    % 从信标点中随机选择一个
    beacon_idx = randi(size(beacons, 1));
    selected_beacon = beacons(beacon_idx, :);
    
    % 在信标周围生成随机点 (均匀圆内分布)
    angle = 2 * pi * rand();
    r = radius * sqrt(rand());  % sqrt保证均匀分布
    
    % 计算采样点
    x = round(selected_beacon(1) + r * cos(angle));
    y = round(selected_beacon(2) + r * sin(angle));
    
    % 边界检查
    x = max(1, min(size(img, 2), x));
    y = max(1, min(size(img, 1), y));
    
    rand_point = [x, y];
end

%% 路径优化函数 (核心创新)
function optimized_path = path_optimization(path, img)
    % 初始化优化路径 (起点)
    optimized_path = path(1, :);
    current_idx = 1;
    
    while current_idx < size(path, 1)
        % 尝试连接当前点到最远的可达点
        for check_idx = size(path, 1):-1:current_idx + 1
            if is_path_valid(img, optimized_path(end, :), path(check_idx, :))
                % 找到可达点，加入优化路径
                optimized_path = [optimized_path; path(check_idx, :)];
                current_idx = check_idx;
                break;
            end
            
            % 如果没有找到直达点，添加下一个点
            if check_idx == current_idx + 1
                optimized_path = [optimized_path; path(current_idx + 1, :)];
                current_idx = current_idx + 1;
            end
        end
    end
end

%% 更新子节点代价 (优化重布线)
function update_child_costs(tree, parent_idx)
    children = find(tree.parent == parent_idx);
    for i = 1:length(children)
        child_idx = children(i);
        tree.cost(child_idx) = tree.cost(parent_idx) + ...
                              node_distance(tree.nodes(parent_idx, :), tree.nodes(child_idx, :));
        update_child_costs(tree, child_idx);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%% 辅助函数 %%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 查找最近节点
function [nearest_idx, nearest_node] = find_nearest_node(nodes, point)
    distances = sum((nodes - point).^2, 2);  % 平方距离加速计算
    [~, nearest_idx] = min(distances);
    nearest_node = nodes(nearest_idx, :);
end

%% 查找邻近节点
function [near_indices, near_nodes] = find_near_nodes(nodes, new_node, radius)
    sq_distances = sum((nodes - new_node).^2, 2);
    near_indices = find(sq_distances <= radius^2);
    near_nodes = nodes(near_indices, :);
end

%% 欧氏距离计算
function dist = node_distance(node1, node2)
    dist = norm(node1 - node2);
end

%% 路径碰撞检测
function is_free = is_path_valid(img, x1, x2)
    % 计算需要检查的点数
    dist = norm(x1 - x2);
    num_points = max(2, ceil(dist));
    t = linspace(0, 1, num_points)';
    
    % 线性插值
    x_points = round(x1(1) + (x2(1) - x1(1)) * t);
    y_points = round(x1(2) + (x2(2) - x1(2)) * t);
    
    % 边界约束
    x_points = max(1, min(size(img, 2), x_points));
    y_points = max(1, min(size(img, 1), y_points));
    
    % 碰撞检查
    indices = sub2ind(size(img), y_points, x_points);
    is_free = all(img(indices));
end

%% 路径重建
function [path, cost] = reconstruct_path(tree, goal_idx)
    path = [];
    cost = 0;
    current_idx = goal_idx;
    
    while current_idx > 0
        path = [tree.nodes(current_idx, :); path];
        if tree.parent(current_idx) > 0
            segment_cost = node_distance(tree.nodes(current_idx, :), tree.nodes(tree.parent(current_idx), :));
            cost = cost + segment_cost;
        end
        current_idx = tree.parent(current_idx);
    end
end

%% 随机采样策略
function [rand_point,o] = adaptive_sample(goal_point,map_size,p,pflag,stop,startpoint)
[~,index]=find(pflag==0,stop+1);
picked = 1+stop;
rand_point = p(index(picked),:).*[map_size(1) map_size(2)];

if rand< 0.1*(1-node_distance(goal_point,rand_point)/node_distance(goal_point,startpoint))
    rand_point = goal_point;  % 目标偏向采样
    o = 0;
else
    o = index(picked);
end
end


%% 动态半径计算
function radius = get_optimal_radius(n, gamma)
    if n < 2
        radius = inf;
        return;
    end
    d = 2;  % 二维空间
    radius = gamma * (log(n)/n)^(1/d);
end

%% 绘制圆形区域
function plotCircle(center, radius)
    theta = linspace(0, 2*pi, 100);
    x = center(1) + radius * cos(theta);
    y = center(2) + radius * sin(theta);
    plot(x, y, 'k-', 'LineWidth', 1);
end
